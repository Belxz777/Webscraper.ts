# Веб-скрейпер для получения расписании АПОУ ИПЭК
## Программа вытаскивает и прокидывает html таблицу , в результате получаем красивый json файл


# Инструкция по запуску :
## 1. Установить необходимые модули , зависимости:
```
npm install

yarn install

pnpm  install

```
2. Запустить код
```
npm run dev

pnpm dev
```
## API DOCS https://documenter.getpostman.com/view/29025992/2sAYXBFf1E
> [!TIP]
> Рекомендуем использвовать pnpm
> [!IMPORTANT]
> По вопросам сотрудничества и обнаруженным багам писать :
> [Telegram](https://web.telegram.org/a/#1718758153)
